import cv2
import logging
import mimetypes
import numpy
import os
import re
import sseclient
import tempfile
import time
from abc import ABC
from requests import get, post, Response
from typing import Generator, Optional, Dict, List, Any, Callable

from .data_classes import InlineMessageButton
from .text_formatter import TextFormatter, TextMarkups, FormattingSettings


class InvalidInviteLinkException(Exception):
    pass


class FileUploadException(Exception):
    pass


class MessageRequest:
    __slots__ = (
        'text',
        'reply_id',
        'buttons',
        'formatting_settings',
    )

    def __init__(self,
                 text: str,
                 reply_id: Optional[int] = None,
                 buttons: Optional[List[InlineMessageButton]] = None,
                 formatting_settings: Optional[FormattingSettings] = None):
        self.text: str = text
        self.reply_id: int = reply_id
        self.buttons: List[InlineMessageButton] = buttons
        self.formatting_settings: FormattingSettings = formatting_settings


class Resource(ABC):
    __slots__ = (
        '_logger',
        'name',
        'content',
    )

    def __init__(self,
                 name: str,
                 content: bytes):
        self._logger = logging.getLogger(__name__)
        self.name: str = name
        self.content: bytes = content

    def _upload_resource(self, upload_url, headers):
        file_param = {'file': (self.name, self.content)}
        file_resp = self._rest_exception_wrapper(
            lambda: post(upload_url, headers=headers, files=file_param))
        if file_resp is not None and file_resp.status_code == 200:
            return file_resp.json()
        else:
            error = f'Upload file failed with status code: {file_resp.status_code}' if file_resp is not None else 'Error'
            raise FileUploadException(error)

    def _rest_exception_wrapper(self, rest_call: Callable) -> Response:
        try:
            return rest_call()
        except Exception as e:
            self._logger.exception('Exception while call rest', exc_info=e)


class File(Resource):
    def upload(self, upload_url: str, headers: Dict) -> Dict:
        """Generates the body for uploading an image."""
        return {
            "fileName": self.name,
            "length": len(self.content),
            "mimeType": mimetypes.MimeTypes().guess_type(self.name)[0],
            "resourceRef": self._upload_resource(upload_url, headers)['resource']
        }


class Image(Resource):
    def upload(self, upload_url: str, headers: Dict) -> Dict:
        """Generates the body for uploading an image."""
        image = self._upload_resource(upload_url, headers)['original']
        return {
            "fileName": self.name,
            "length": len(self.content),
            "width": image['width'],
            "height": image['height'],
            "mimeType": mimetypes.MimeTypes().guess_type(self.name)[0],
            "resourceRef": image['resource']
        }


class Video(Resource):
    def upload(self, upload_url: str, upload_thumbnail_url: str, headers: Dict) -> Dict:
        """Generates the body for uploading a video."""
        with tempfile.NamedTemporaryFile(delete=True) as temp_video_file:
            temp_video_file.write(self.content)
            temp_video_file.flush()
            video_capture = cv2.VideoCapture(temp_video_file.name)

            if video_capture is not None:
                width = int(video_capture.get(cv2.CAP_PROP_FRAME_WIDTH))
                height = int(video_capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
                thumbnail = self._get_thumbnail(video_capture, upload_thumbnail_url, headers)
                video_capture.release()
                return {
                    "fileName": self.name,
                    "length": len(self.content),
                    "width": width,
                    "height": height,
                    "thumbnailResourceRef": thumbnail["resourceRef"],
                    "mimeType": mimetypes.MimeTypes().guess_type(self.name)[0],
                    "resourceRef": self._upload_resource(upload_url, headers)['resource']
                }

    def _get_thumbnail(self, video_capture: cv2.VideoCapture, image_upload_url: str, headers: Dict):
        success, encoded_image = cv2.imencode('.jpg', Video.__get_frame(video_capture))
        if success:
            thumbnail_name = f'thumbnail_{self.name}.jpg'
            thumbnail_content = numpy.array(encoded_image).tobytes()
            return Image(thumbnail_name, thumbnail_content).upload(image_upload_url, headers)
        else:
            raise FileUploadException('Error while encoding image')

    @staticmethod
    def __get_frame(video_capture: cv2.VideoCapture):
        Video.__valid_video_capture(video_capture)
        video_capture.set(cv2.CAP_PROP_POS_FRAMES, 1)
        ret, frame = video_capture.read()
        if ret:
            return frame
        else:
            raise FileUploadException('Failed to read frame')

    @staticmethod
    def __valid_video_capture(video_capture: cv2.VideoCapture):
        if not video_capture.isOpened():
            raise FileUploadException('Failed to open video')

        frame_count = int(video_capture.get(cv2.CAP_PROP_FRAME_COUNT))
        if frame_count < 0:
            raise FileUploadException('The frame number is outside the total number of frames')


class Request:
    """Makes rest calls to bot api"""

    __slots__ = (
        '_logger',
        '_base_headers',
        '_group_id_header',
        '_workspace_id_header',
        '_sse_url',
        '_api_confirm_url',
        '_api_confirm_events_url',
        '_api_send_text_url',
        '_api_send_file_url',
        '_api_get_states_url',
        '_api_get_state_url',
        '_api_file_upload_url',
        '_api_image_upload_url',
        '_api_get_messages_url',
        '_api_get_all_unread_messages_url',
        '_api_delete_messages_url',
        '_api_update_text_message_url',
        '_api_send_multimedia_url',
        '_api_update_multimedia_url',
        '_api_send_image_url',
        '_api_update_image_url',
        '_api_send_video_url',
        '_api_update_video_url',
        '_api_update_file_message_url',
        '_api_join_user_by_invite_link_url',
        '_invite_link_pattern',
        '_formatter',
    )

    def __init__(self, token: str,
                 api_base_url: Optional[str] = None,
                 file_upload_base_url: Optional[str] = None,
                 sse_base_url: Optional[str] = None,
                 group_id: Optional[int] = None,
                 workspace_id: Optional[int] = None,
                 formatter: Optional[TextFormatter] = TextFormatter(),
                 server_resource_encryption: bool = True):
        self._logger = logging.getLogger(__name__)
        if not api_base_url:
            api_base_url = ''
        if not file_upload_base_url:
            file_upload_base_url = ''
        if not sse_base_url:
            sse_base_url = ''
        self._base_headers: Dict[str, str] = {"Authorization": token}
        self._group_id_header: Dict[str, str] = {} if group_id is None else {"groupId": str(group_id)}
        self._workspace_id_header: Dict[str, str] = {} if workspace_id is None else {"workspaceId": str(workspace_id)}
        self._sse_url: str = sse_base_url + ('/api/v2/events/bot' if group_id is None else '/api/v2/events/bot/group')
        self._api_confirm_url: str = api_base_url + '/botapi/v1/messages/confirm/{}/{}'
        self._api_confirm_events_url: str = api_base_url + '/botapi/v1/groups/confirmEvents/{}'
        self._api_send_text_url: str = api_base_url + '/botapi/v1/messages/sendTextMessage/{}/{}'
        self._api_send_file_url: str = api_base_url + '/botapi/v1/messages/sendFile/{}/{}'
        self._api_get_states_url: str = api_base_url + '/botapi/v1/groups/getAllUserGroupStates'
        self._api_get_state_url: str = api_base_url + '/botapi/v1/groups/getUserGroupState/{}/{}'
        self._api_file_upload_url: str = file_upload_base_url + (
            '/api/v1/upload/secret/encryptable' if server_resource_encryption else '/api/v1/upload')
        self._api_image_upload_url: str = file_upload_base_url + (
            '/api/v1/upload/image/encryptable' if server_resource_encryption else '/api/v1/upload/image')
        self._api_get_messages_url: str = api_base_url + '/botapi/v1/messages/getMessages/{}/{}'
        self._api_get_all_unread_messages_url: str = api_base_url + '/botapi/v1/messages/getAllUnreadMessages/{}/{}'
        self._api_delete_messages_url: str = api_base_url + '/botapi/v1/messages/deleteMessages/{}/{}'
        self._api_update_text_message_url: str = api_base_url + '/botapi/v1/messages/updateTextMessage/{}/{}/{}'
        self._api_update_file_message_url: str = api_base_url + '/botapi/v1/messages/updateFile/{}/{}/{}'
        self._api_send_multimedia_url: str = api_base_url + '/botapi/v1/messages/sendMultimedia/{}/{}'
        self._api_update_multimedia_url: str = api_base_url + '/botapi/v1/messages/updateMultimedia/{}/{}/{}'
        self._api_send_image_url: str = api_base_url + '/botapi/v1/messages/sendImage/{}/{}'
        self._api_update_image_url: str = api_base_url + '/botapi/v1/messages/updateImage/{}/{}/{}'
        self._api_send_video_url: str = api_base_url + '/botapi/v1/messages/sendVideo/{}/{}'
        self._api_update_video_url: str = api_base_url + '/botapi/v1/messages/updateVideo/{}/{}/{}'
        self._api_join_user_by_invite_link_url: str = api_base_url + '/botapi/v1/workspaces/joinUserByInviteLink'
        self._formatter: TextFormatter = formatter
        self._invite_link_pattern = re.compile(r'^(https?://)[^\s]+/'
                                               r'[^\s]*[0-9a-fA-F]{8}'
                                               r'-[0-9a-fA-F]{4}'
                                               r'-[0-9a-fA-F]{4}'
                                               r'-[0-9a-fA-F]{4}'
                                               r'-[0-9a-fA-F]{12}$', re.IGNORECASE)

    def _retry_get_wrapper(self, url, delay=5, params: Dict = None, **kwargs):  # use decorator instead, exmp tenacity
        while True:
            try:
                resp = get(url, params, **kwargs)
                if 200 <= resp.status_code <= 299:
                    return resp
                else:
                    time.sleep(delay)
                    continue
            except Exception as e:
                self._logger.exception('Exception with connection to bot api', exc_info=e)
                time.sleep(delay)

    def _rest_exception_wrapper(self, rest_call: Callable) -> Response:
        try:
            return rest_call()
        except Exception as e:
            self._logger.exception('Exception while call rest', exc_info=e)

    def sse(self) -> Generator[sseclient.Event, None, None]:
        headers = {**self._base_headers, **self._group_id_header, **self._workspace_id_header}
        return sseclient.SSEClient(
            self._retry_get_wrapper(self._sse_url, stream=True, headers=headers)).events()

    def confirm(self, workspace_id: int, group_id: int, last_msg_id: int) -> None:
        resp = self._rest_exception_wrapper(
            lambda: post(self._api_confirm_url.format(workspace_id, group_id), headers=self._base_headers,
                         json={"lastMessageId": last_msg_id}))
        if resp is None or resp.status_code != 200:
            self._logger.exception('Request to confirm message in group[wid=%d,gid=%d] with last_msg_id=%d failed',
                                   workspace_id, group_id, last_msg_id)

    def confirm_events(self, workspace_id: int, event_id_by_group_id_dict: Dict[int, int]) -> None:
        resp = self._rest_exception_wrapper(lambda: post(
            self._api_confirm_events_url.format(workspace_id),
            headers=self._base_headers,
            json=self.__generate_confirm_events_body(event_id_by_group_id_dict)))
        if resp is None or resp.status_code != 200:
            self._logger.exception('Request to confirm events in workspace id=%d, %s failed', workspace_id, "; ".join(
                [f"group id={key}, event id={value}" for key, value in event_id_by_group_id_dict.items()]))

    def get_states(self) -> List[Dict[str, Any]]:
        resp = post(self._api_get_states_url, headers=self._base_headers, json={})
        if resp.status_code != 200:
            self._logger.exception('Request to get states failed')
            raise RuntimeError('Fetching bot group states failed')
        return resp.json()

    def get_state(self, workspace_id: int, group_id: int) -> Dict[str, Any]:
        resp = post(self._api_get_state_url.format(workspace_id, group_id), headers=self._base_headers, json={})
        if resp.status_code != 200:
            self._logger.exception('Request to get state[wid=%d,gid=%d] failed', workspace_id, group_id)
            raise RuntimeError('Fetching bot group state failed')
        return resp.json()

    def send_text(self, workspace_id: int, group_id: int, message: MessageRequest) -> Dict[str, Any]:
        formatting_settings = self._get_formatting_settings(message)

        resp = self._rest_exception_wrapper(
            lambda: post(self._api_send_text_url.format(workspace_id, group_id), headers=self._base_headers,
                         json={"message": formatting_settings.message,
                               "clientRandomId": int(time.time()),
                               "replyMsgId": message.reply_id,
                               "buttonsMarkup": Request.__generate_buttons_body(message.buttons),
                               **({"entities": Request.__generate_entities_body(formatting_settings.text_markups)}
                                  if formatting_settings.text_markups is not None else {})
                               }))
        if resp is None or resp.status_code != 200:
            error = (f'Request to send text message in group[wid={workspace_id},gid={group_id}] '
                     f'with status code: {resp.status_code} failed ({resp.text})') if resp is not None \
                else f'Request to send text message in group[wid={workspace_id},gid={group_id}] failed'
            self._logger.exception(error)
        else:
            return resp.json()

    def send_multimedia(self, workspace_id: int, group_id: int,
                        images: Optional[List[Image]] = None,
                        video: Optional[List[Video]] = None,
                        text: str = '') -> Dict[str, Any]:
        url = self._api_send_multimedia_url.format(workspace_id, group_id)
        return self._send_multimedia(url, MessageRequest(text), images, video).json()

    def send_multimedia_message(self, workspace_id: int, group_id: int,
                                images: Optional[List[Image]] = None,
                                video: Optional[List[Video]] = None,
                                message: Optional[MessageRequest] = MessageRequest('')) -> Dict[str, Any]:
        url = self._api_send_multimedia_url.format(workspace_id, group_id)
        return self._send_multimedia(url, message, images, video).json()

    def _send_multimedia(self,
                         url: str,
                         message: MessageRequest,
                         images: Optional[List[Image]] = None,
                         videos: Optional[List[Video]] = None) -> Response:
        if images is None and videos is None:
            raise FileUploadException('No files to download')

        formatting_settings = self._get_formatting_settings(message)

        uploaded_images = [image.upload(self._api_image_upload_url, self._base_headers)
                           for image in images] if images is not None else []
        uploaded_videos = [video.upload(self._api_file_upload_url, self._api_image_upload_url, self._base_headers)
                           for video in videos] if videos is not None else []

        multimedia = self.__generate_multimedia_body(uploaded_images, uploaded_videos)
        msg_payload = {
            "message": formatting_settings.message,
            "clientRandomId": int(time.time()),
            "replyMsgId": message.reply_id,
            "buttonsMarkup": Request.__generate_buttons_body(message.buttons),
            **({"entities": Request.__generate_entities_body(formatting_settings.text_markups)}
               if formatting_settings.text_markups is not None else {}),
            "multimedia": multimedia
        }
        msg_resp = self._rest_exception_wrapper(lambda: post(url, headers=self._base_headers, json=msg_payload))
        if msg_resp is None or msg_resp.status_code != 200:
            error = (f'Request to send message with file failed '
                     f'with status code: {msg_resp.status_code}') if msg_resp is not None else 'Error uploading file'
            raise FileUploadException(error)
        return msg_resp

    def send_image(self, workspace_id: int, group_id: int, image_path: str, text: str = '') -> Dict[str, Any]:
        with open(image_path, 'rb') as file:
            file_name = os.path.basename(image_path)
            image = Image(file_name, file.read())
            return self.send_image_message(workspace_id, group_id, image, MessageRequest(text))

    def send_image_message(self, workspace_id: int, group_id: int, image: Image,
                           message: MessageRequest = MessageRequest("")) -> Dict[str, Any]:
        return self._send_image(image, self._api_send_image_url.format(workspace_id, group_id), message).json()

    def update_image(self,
                     workspace_id: int,
                     group_id: int,
                     message_id: int,
                     image_path: str,
                     new_text: '') -> Dict[str, Any]:
        with open(image_path, 'rb') as file:
            file_name = os.path.basename(image_path)
            image = Image(file_name, file.read())
            return self.update_image_message(workspace_id, group_id, message_id, image, MessageRequest(new_text))

    def update_image_message(self,
                             workspace_id: int,
                             group_id: int,
                             message_id: int,
                             image: Image,
                             new_message: MessageRequest = MessageRequest('')) -> Dict[str, Any]:
        url = self._api_update_image_url.format(workspace_id, group_id, message_id)
        return self._send_image(image, url, new_message).json()

    def _send_image(self, image: Image, url: str, message: MessageRequest) -> Response:
        formatting_settings = self._get_formatting_settings(message)
        msg_payload = {
            "message": formatting_settings.message,
            "clientRandomId": int(time.time()),
            "replyMsgId": message.reply_id,
            "buttonsMarkup": Request.__generate_buttons_body(message.buttons),
            **({"entities": Request.__generate_entities_body(formatting_settings.text_markups)}
               if formatting_settings.text_markups is not None else {}),
            "image": image.upload(self._api_image_upload_url, self._base_headers)
        }
        msg_resp = self._rest_exception_wrapper(lambda: post(url, headers=self._base_headers, json=msg_payload))
        if msg_resp is None or msg_resp.status_code != 200:
            error = (f'Request to send message with image failed '
                     f'with status code: {msg_resp.status_code}') if msg_resp else 'Error uploading image'
            raise FileUploadException(error)
        return msg_resp

    def send_video(self, workspace_id: int, group_id: int, video_path: str, text: str = '') -> Dict[str, Any]:
        with open(video_path, 'rb') as file:
            file_name = os.path.basename(video_path)
            video = Video(file_name, file.read())
            return self.send_video_message(workspace_id, group_id, video, MessageRequest(text))

    def send_video_message(self, workspace_id: int, group_id: int, video: Video,
                           message: MessageRequest = MessageRequest("")) -> Dict[str, Any]:
        return self._send_video(video, self._api_send_video_url.format(workspace_id, group_id), message).json()

    def update_video(self,
                     workspace_id: int,
                     group_id: int,
                     message_id: int,
                     video_path: str,
                     new_text: '') -> Dict[str, Any]:
        with open(video_path, 'rb') as file:
            file_name = os.path.basename(video_path)
            video = Video(file_name, file.read())
            return self.update_video_message(workspace_id, group_id, message_id, video, MessageRequest(new_text))

    def update_video_message(self,
                             workspace_id: int,
                             group_id: int,
                             message_id: int,
                             video: Video,
                             new_message: MessageRequest = MessageRequest('')) -> Dict[str, Any]:
        url = self._api_update_video_url.format(workspace_id, group_id, message_id)
        return self._send_video(video, url, new_message).json()

    def _send_video(self, video: Video, url: str, message: MessageRequest) -> Response:
        formatting_settings = self._get_formatting_settings(message)
        msg_payload = {
            "message": formatting_settings.message,
            "clientRandomId": int(time.time()),
            "replyMsgId": message.reply_id,
            "buttonsMarkup": Request.__generate_buttons_body(message.buttons),
            **({"entities": Request.__generate_entities_body(formatting_settings.text_markups)}
               if formatting_settings.text_markups is not None else {}),
            "video": video.upload(self._api_file_upload_url, self._api_image_upload_url, self._base_headers)
        }

        msg_resp = self._rest_exception_wrapper(lambda: post(url, headers=self._base_headers, json=msg_payload))
        if msg_resp is None or msg_resp.status_code != 200:
            error = (f'Request to send message with video failed '
                     f'with status code: {msg_resp.status_code}') if msg_resp else 'Error uploading video'
            raise FileUploadException(error)
        return msg_resp

    def send_file(self, workspace_id: int, group_id: int, file_path: str, text: str = '') -> Dict[str, Any]:
        with open(file_path, 'rb') as file:
            file_name = os.path.basename(file_path)
            file = File(file_name, file.read())
            return self.send_file_message(workspace_id, group_id, file, MessageRequest(text))

    def send_file_message(self, workspace_id: int, group_id: int, file: File,
                          message: MessageRequest = MessageRequest('')) -> Dict[str, Any]:
        return self._send_file(file, self._api_send_file_url.format(workspace_id, group_id), message).json()

    def update_file(self,
                    workspace_id: int,
                    group_id: int,
                    message_id: int,
                    file_path: str,
                    new_text: '') -> Dict[str, Any]:
        with open(file_path, 'rb') as file:
            file_name = os.path.basename(file_path)
            file = File(file_name, file.read())
            return self.update_file_message(workspace_id, group_id, message_id, file, MessageRequest(new_text))

    def update_file_message(self,
                            workspace_id: int,
                            group_id: int,
                            message_id: int,
                            file: File,
                            new_message: MessageRequest = MessageRequest('')) -> Dict[str, Any]:
        url = self._api_update_file_message_url.format(workspace_id, group_id, message_id)
        return self._send_file(file, url, new_message).json()

    def _send_file(self, file: File, url: str, message: MessageRequest) -> Response:
        formatting_settings = self._get_formatting_settings(message)
        msg_payload = {
            "message": formatting_settings.message,
            "clientRandomId": int(time.time()),
            "replyMsgId": message.reply_id,
            "buttonsMarkup": Request.__generate_buttons_body(message.buttons),
            **({"entities": Request.__generate_entities_body(formatting_settings.text_markups)}
               if formatting_settings.text_markups is not None else {}),
            "file": file.upload(self._api_file_upload_url, self._base_headers)
        }

        msg_resp = self._rest_exception_wrapper(lambda: post(url, headers=self._base_headers, json=msg_payload))
        if msg_resp is None or msg_resp.status_code != 200:
            error = (f'Request to send message with file failed '
                     f'with status code: {msg_resp.status_code}') if msg_resp else 'None'
            raise FileUploadException(error)
        return msg_resp

    def get_messages(self, workspace_id: int, group_id: int, message_ids: List[int]) -> List[Dict[str, Any]]:
        if not message_ids:
            self._logger.warning('Do not send request, the message_ids is empy')
            return []
        resp = self._rest_exception_wrapper(
            lambda: post(self._api_get_messages_url.format(workspace_id, group_id), headers=self._base_headers,
                         json={"messageIds": message_ids}))
        if resp is None or resp.status_code != 200:
            self._logger.exception('Request to get messages failed')
            return []
        return resp.json()

    def get_all_unread_messages(self, workspace_id: int, group_id: int) -> List[Dict[str, Any]]:
        resp = self._rest_exception_wrapper(
            lambda: post(self._api_get_all_unread_messages_url.format(workspace_id, group_id),
                         headers=self._base_headers,
                         json={}))
        if resp is None or resp.status_code != 200:
            self._logger.exception('Request to get all unread messages failed')
            return []
        return resp.json()

    def delete_messages(self, workspace_id: int, group_id: int, message_ids: List[int]) -> None:
        if not message_ids:
            self._logger.warning('Do not send request, the message_ids is empy')
            return
        resp = self._rest_exception_wrapper(
            lambda: post(self._api_delete_messages_url.format(workspace_id, group_id), headers=self._base_headers,
                         json={"messageIds": message_ids}))
        if resp is None or resp.status_code != 200:
            self._logger.exception('Request to delete messages in group[wid=%d,gid=%d] failed',
                                   workspace_id, group_id)

    def join_user_by_invite_link(self, link: str) -> None:
        self.validate_invite_link(link)
        resp = self._rest_exception_wrapper(
            lambda: post(self._api_join_user_by_invite_link_url, headers=self._base_headers, json={"inviteLink": link}))
        if resp is None or resp.status_code != 200:
            raise InvalidInviteLinkException(f'Request to join user by invite link [link={link}] failed')

    def update_text_message(self, workspace_id: int, group_id: int, message_id: int, new_message: str) -> Dict[
        str, Any]:
        return self.update_message(workspace_id, group_id, message_id, MessageRequest(new_message))

    def update_message(self, workspace_id: int, group_id: int, message_id: int, new_message: MessageRequest) -> Dict[
        str, Any]:
        if not new_message:
            self._logger.warning('Do not send request, the new_message is empy')
            return {}
        formatting_settings = self._get_formatting_settings(new_message)
        resp = self._rest_exception_wrapper(
            lambda: post(self._api_update_text_message_url.format(workspace_id, group_id, message_id),
                         headers=self._base_headers,
                         json={"message": formatting_settings.message,
                               "buttonsMarkup": Request.__generate_buttons_body(new_message.buttons),
                               **({"entities": Request.__generate_entities_body(formatting_settings.text_markups)}
                                  if formatting_settings.text_markups is not None else {}),
                               }))
        if resp is None or resp.status_code != 200:
            self._logger.exception('Request to update message failed')
            return {}
        return resp.json()

    def validate_invite_link(self, link: str):
        if not re.match(self._invite_link_pattern, link):
            raise InvalidInviteLinkException(f"Invalid URL: {link}")

    def _get_formatting_settings(self, message: MessageRequest) -> FormattingSettings:
        if self._formatter is None or message.formatting_settings is not None:
            return message.formatting_settings
        else:
            return self._formatter.format_text(message.text)

    @staticmethod
    def __generate_confirm_events_body(event_id_by_group_id_dict: Dict[int, int]):
        return {
            "events": [
                {
                    "groupId": group_id,
                    "lastReceivedEventId": event_id_by_group_id_dict[group_id]
                } for group_id in event_id_by_group_id_dict
            ]}

    @staticmethod
    def __generate_buttons_body(buttons: List[InlineMessageButton]):
        return {
            "inlineMessageButtons": [
                {
                    "id": button.id,
                    "label": button.label,
                    **({"callbackMessage": button.callback_message} if button.callback_message is not None else {}),
                    **({"callbackData": button.callback_data} if button.callback_data is not None else {})
                } for button in buttons
            ]
        } if buttons is not None else None

    @staticmethod
    def __generate_entities_body(text_markups: TextMarkups):
        return ([{'bold': entity.convert_to_dict()} for entity in text_markups.bold] +
                [{'italic': entity.convert_to_dict()} for entity in text_markups.italic] +
                [{'strike': entity.convert_to_dict()} for entity in text_markups.strike] +
                [{'underline': entity.convert_to_dict()} for entity in text_markups.underline] +
                [{'monospace': entity.convert_to_dict()} for entity in text_markups.monospace] +
                [{'textUrl': entity.convert_to_dict()} for entity in text_markups.url] +
                [{'textFormattedUrl': entity.convert_to_dict()} for entity in text_markups.formatted_url] +
                [{'botCommand': entity.convert_to_dict()} for entity in text_markups.command])

    @staticmethod
    def __generate_multimedia_body(images: List[Dict], videos: List[Dict]):
        return ([{'image': image, 'position': idx} for idx, image in enumerate(images)] +
                [{'video': video, 'position': len(images) + idx} for idx, video in enumerate(videos)])
