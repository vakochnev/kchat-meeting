import logging
import traceback
from queue import Queue, Empty
from threading import Lock, current_thread, Thread, Event
from typing import List, Callable, Dict, Optional, Any, Generator

from .event import (BotEvent, MessageBotEvent, MessageUpdateBotEvent, MessageDeleteBotEvent, MessagesDeleteBotEvent,
                    GroupUserRemoveBotEvent, GroupMeRemoveBotEvent, GroupUserLeaveBotEvent, GroupUsersAddBotEvent,
                    GroupUserJoinBotEvent, GroupMeAddBotEvent, UserSignedUpToWorkspaceBotEvent,
                    HistoryClearGroupBotEvent, DeleteGroupBotEvent, UserUpdateBotEvent,
                    MessagesDeletedCompletelyBotEvent)
from .handler import Handler
from .util import Request


class Application(object):
    __slots__ = (
        '_logger',
        '_token',
        '_request',
        '__event_queue',
        '__group_states',
        '__bot_user_id',
        '__started',
        '__lock',
        '__threads',
        '__sse_handlers',
        '__fetcher_exception',
        '__fetcher_stop',
        '__handler_exception',
        '__handler_stop',
        '__event_map',
    )

    def __init__(self, token: Optional[str] = None, request_kwargs: Optional[Dict[str, Any]] = None):
        if token is None:
            raise ValueError('Bot token must be specified')

        self._logger = logging.getLogger(__name__)
        self._token = token

        if request_kwargs is None:
            request_kwargs = {}
        self._request = Request(**{'token': token}, **request_kwargs)
        # self._sse_last_event_id: str = '0'

        self.__group_states: Dict[int, Dict[str, Any]] = {}
        self.__bot_user_id: int = 0

        self.__event_queue: Queue = Queue()
        self.__started = False
        self.__lock = Lock()
        self.__threads: List[Thread] = []
        self.__sse_handlers: List[Handler] = []

        self.__fetcher_exception = Event()
        self.__fetcher_stop = Event()
        self.__handler_exception = Event()
        self.__handler_stop = Event()
        self.__event_map = {
            BotEvent.PING: lambda request, sse: BotEvent(request, sse),
            BotEvent.MESSAGE: lambda request, sse: MessageBotEvent(request, sse),
            BotEvent.MESSAGES_DELETED: lambda request, sse: MessagesDeleteBotEvent(request, sse),
            BotEvent.MESSAGES_DELETED_COMPLETELY: lambda request, sse: MessagesDeletedCompletelyBotEvent(request, sse),
            BotEvent.MESSAGE_DELETE: lambda request, sse: MessageDeleteBotEvent(request, sse),
            BotEvent.MESSAGE_UPDATE: lambda request, sse: MessageUpdateBotEvent(request, sse),
            BotEvent.GROUP_USER_REMOVE: lambda request, sse: GroupUserRemoveBotEvent(request, sse),
            BotEvent.GROUP_ME_REMOVE: lambda request, sse: GroupMeRemoveBotEvent(request, sse),
            BotEvent.GROUP_USER_LEAVE: lambda request, sse: GroupUserLeaveBotEvent(request, sse),
            BotEvent.GROUP_USERS_ADD: lambda request, sse: GroupUsersAddBotEvent(request, sse),
            BotEvent.GROUP_ME_ADD: lambda request, sse: GroupMeAddBotEvent(request, sse),
            BotEvent.GROUP_USER_JOIN: lambda request, sse: GroupUserJoinBotEvent(request, sse),
            BotEvent.GROUP_HISTORY_CLEAR: lambda request, sse: HistoryClearGroupBotEvent(request, sse),
            BotEvent.GROUP_DELETE: lambda request, sse: DeleteGroupBotEvent(request, sse),
            BotEvent.USER_SIGNED_UP_TO_WORKSPACE: lambda request, sse: UserSignedUpToWorkspaceBotEvent(request, sse),
            BotEvent.USER_UPDATE: lambda request, sse: UserUpdateBotEvent(request, sse),
        }

    def start(self):
        self._logger.info('Starting bot ...')
        with self.__lock:
            if not self.__started:
                self.__group_states = {s['groupId']: s for s in self._request.get_states()}
                self.__bot_user_id = self._get_bot_user_id()
                self._start_thread(self._event_fetcher_loop, 'sse_fetcher', self.__fetcher_exception)
                self._start_thread(self._event_handler_loop, 'sse_handler', self.__handler_exception)
                self.__started = True
                self._logger.info('Bot started')
            else:
                self._logger.warning('Bot is already started')

    def _get_bot_user_id(self):
        for group_id, state in self.__group_states.items():
            group_type = state.get('group', {}).get('type', '')
            if group_type.lower() == 'system':
                return group_id

        raise ValueError('Bot user id is not found')

    def _event_fetcher_loop(self):
        self._logger.info('Sse events fetcher loop started')
        while True:
            try:
                for event in self._fetch_sse():
                    if event is not None and not event.is_ping and (
                            event.sender_id is None or (
                            event.sender_id != self.__bot_user_id and event.sender_id != -100)):
                        self.__event_queue.put(event)
                    # if event.id is not None:
                    #     self._sse_last_event_id = event.id
                    if self.__handler_exception.is_set():
                        self._logger.critical('Sse events fetcher loop stopped due to exception in handler thread')
                        break
                    if self.__fetcher_stop.is_set():
                        self._logger.info('Sse events fetcher loop stopped')
                        break
            except Exception as e:
                self._logger.exception('Exception while read sse', exc_info=e)

    def _map_to_bot_event(self, sse) -> Optional[BotEvent]:
        event_type = sse.event.lower()
        event = self.__event_map.get(event_type, None)
        if event is not None:
            return event(self._request, sse)
        else:
            self._logger.warning(f'{event_type} not supported')
            return None

    def _fetch_sse(self) -> Generator[BotEvent, None, None]:
        return (self._map_to_bot_event(e) for e in self._request.sse())

    def _event_handler_loop(self):
        self._logger.info('Sse events handler loop started')
        while True:
            try:
                event = self.__event_queue.get(True, 1)
            except Empty:
                if self.__fetcher_exception.is_set():
                    self._logger.critical('Sse events handler loop stopped due to exception in fetcher thread')
                    break
                if self.__handler_stop.is_set():
                    self._logger.info('Sse events handler loop stopped')
                    break
                continue

            self._handle_event(event)
            self.__event_queue.task_done()

    def stop(self):
        self._logger.info('Stopping bot')
        with self.__lock:
            if self.__started:
                self._stop_threads()
                self._logger.info('Bot stopped')
            else:
                self._logger.warning('Bot is already stopped')

    def _stop_threads(self) -> None:
        for thread in self.__threads:
            thread.join()
            self._logger.debug('%s thread stopped', thread.name)
        self.__threads = []

    def add_handler(self, handler: Handler) -> None:
        if not isinstance(handler, Handler):
            raise TypeError(f'The handler parameter is not an instance of {Handler.__name__}')
        self.__sse_handlers.append(handler)

    def _start_thread(self, target: Callable, name: str, exception_event: Optional[Event] = None, *args: object,
                      **kwargs: object) -> None:
        thread = Thread(
            target=self._thread_exception_wrapper,
            name=f'Bot:{name}',
            args=(target, exception_event,) + args,
            kwargs=kwargs,
        )
        thread.start()
        self.__threads.append(thread)

    def _thread_exception_wrapper(self, target: Callable, exception_event: Optional[Event] = None, *args: object,
                                  **kwargs: object) -> None:
        thread_name = current_thread().name
        self._logger.info('Thread %s - started', thread_name)
        try:
            target(*args, **kwargs)
        except Exception:
            if exception_event is not None:
                exception_event.set()
            self._logger.exception('Exception in thread %s: %s', thread_name, traceback.format_exc())
            raise
        self._logger.info('Thread %s - finished', thread_name)

    def _handle_event(self, event: BotEvent) -> None:
        try:
            for handler in self.__sse_handlers:
                check = handler.should_handle(event)
                if check is True:
                    handler.handle(event)
                    break

        except Exception as e:
            self._logger.exception('Processing sse failed with the error', exc_info=e)

        # TODO save state
