import re
from abc import ABC, abstractmethod
from typing import Callable, TypeVar

from .event import (BotEvent, MessageBotEvent, MessageUpdateBotEvent, MessageDeleteBotEvent, MessagesDeleteBotEvent,
                    GroupUserRemoveBotEvent, GroupMeRemoveBotEvent, GroupUserLeaveBotEvent, GroupUsersAddBotEvent,
                    GroupUserJoinBotEvent, GroupMeAddBotEvent, UserSignedUpToWorkspaceBotEvent,
                    HistoryClearGroupBotEvent, DeleteGroupBotEvent, UserUpdateBotEvent,
                    MessagesDeletedCompletelyBotEvent)

T = TypeVar('T', bound='BotEvent')


class Handler(ABC):
    """Bot command handler interface"""

    __slots__ = ('_callback')

    def __init__(self, callback: Callable[[T], None]):
        self._callback = callback

    @abstractmethod
    def should_handle(self, e: T) -> bool:
        """Checks whether this handler can handle this event"""
        pass

    def handle(self, e: T) -> None:
        """Handles the event"""
        self._callback(e)


class CommandHandler(Handler):
    __slots__ = ('_command',)

    def __init__(self, command: str, callback: Callable[[MessageBotEvent], None]):
        if not re.match(r'^\w+$', command):
            raise ValueError('Command is not a valid bot command')

        super().__init__(callback)
        self._command = command.lower()

    def should_handle(self, e: MessageBotEvent) -> bool:
        if e.is_message and e.message_text:
            match = re.search(r'/(\w+)', e.message_text)
            if match:
                cmd = match.group(1)
                return cmd.lower() == self._command

        return False


class EventHandler(Handler):
    __slots__ = ('_event_types',)

    def __init__(self, event_types: [str], callback: Callable[[T], None]):
        super().__init__(callback)
        self._event_types = event_types

    def should_handle(self, e: T) -> bool:
        return e.event_type in self._event_types


class DeleteMessageEventHandler(EventHandler):
    def __init__(self, callback: Callable[[MessageDeleteBotEvent], None]):
        super().__init__(BotEvent.MESSAGE_DELETE, callback)


class DeleteMessagesEventHandler(EventHandler):
    def __init__(self, callback: Callable[[MessagesDeleteBotEvent], None]):
        super().__init__(BotEvent.MESSAGES_DELETED, callback)


class MessagesDeletedCompletelyHandler(EventHandler):
    def __init__(self, callback: Callable[[MessagesDeletedCompletelyBotEvent], None]):
        super().__init__(BotEvent.MESSAGES_DELETED_COMPLETELY, callback)


class UpdateMessageEventHandler(EventHandler):
    def __init__(self, callback: Callable[[MessageUpdateBotEvent], None]):
        super().__init__([BotEvent.MESSAGE_UPDATE], callback)


class MessageHandler(EventHandler):
    def __init__(self, callback: Callable[[MessageBotEvent], None]):
        super().__init__([BotEvent.MESSAGE], callback)


class GroupUserJoinHandler(EventHandler):
    def __init__(self, callback: Callable[[GroupUserJoinBotEvent], None]):
        super().__init__([BotEvent.GROUP_USER_JOIN], callback)


class GroupUsersAddHandler(EventHandler):
    def __init__(self, callback: Callable[[GroupUsersAddBotEvent], None]):
        super().__init__([BotEvent.GROUP_USERS_ADD], callback)


class GroupUserLeaveHandler(EventHandler):
    def __init__(self, callback: Callable[[GroupUserLeaveBotEvent], None]):
        super().__init__([BotEvent.GROUP_USER_LEAVE], callback)


class GroupUserRemoveHandler(EventHandler):
    def __init__(self, callback: Callable[[GroupUserRemoveBotEvent], None]):
        super().__init__([BotEvent.GROUP_USER_REMOVE], callback)


class GroupMeAddHandler(EventHandler):
    def __init__(self, callback: Callable[[GroupMeAddBotEvent], None]):
        super().__init__([BotEvent.GROUP_ME_ADD], callback)


class GroupMeRemoveHandler(EventHandler):
    def __init__(self, callback: Callable[[GroupMeRemoveBotEvent], None]):
        super().__init__([BotEvent.GROUP_ME_REMOVE], callback)


class GroupHistoryClearHandler(EventHandler):
    def __init__(self, callback: Callable[[HistoryClearGroupBotEvent], None]):
        super().__init__([BotEvent.GROUP_HISTORY_CLEAR], callback)


class GroupDeleteHandler(EventHandler):
    def __init__(self, callback: Callable[[DeleteGroupBotEvent], None]):
        super().__init__([BotEvent.GROUP_DELETE], callback)


class UserSignedUpToWorkspaceHandler(EventHandler):
    def __init__(self, callback: Callable[[UserSignedUpToWorkspaceBotEvent], None]):
        super().__init__([BotEvent.USER_SIGNED_UP_TO_WORKSPACE], callback)


class UserUpdateHandler(EventHandler):
    def __init__(self, callback: Callable[[UserUpdateBotEvent], None]):
        super().__init__([BotEvent.USER_UPDATE], callback)


class ClickButtonEventHandler(Handler):
    def should_handle(self, e: MessageBotEvent) -> bool:
        return e.is_message and e.has_selected_button
