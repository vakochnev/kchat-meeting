import re
from typing import List, Dict, Optional


class TextMarkup:
    __slots__ = (
        'offset',
        'length'
    )

    def __init__(self, offset: int, length: int):
        self.offset: int = offset
        self.length: int = length

    def __str__(self):
        return f"offset: {self.offset} length: {self.length}"

    def convert_to_dict(self):
        return {
            "offset": self.offset,
            "length": self.length
        }


class TextUrlMarkup(TextMarkup):
    __slots__ = (
        'url'
    )

    def __init__(self, offset: int, length: int, url: str):
        super().__init__(offset, length)
        self.url: str = url

    def __str__(self):
        return f"offset: {self.offset} length: {self.length} url: {self.url}"

    def convert_to_dict(self):
        return {
            "offset": self.offset,
            "length": self.length,
            "url": self.url,
        }


class TextMarkups:
    __slots__ = ('bold', 'italic', 'underline', 'strike', 'monospace', 'url', 'formatted_url', 'command')

    def __init__(self):
        self.bold: List[TextMarkup] = []
        self.italic: List[TextMarkup] = []
        self.underline: List[TextMarkup] = []
        self.strike: List[TextMarkup] = []
        self.monospace: List[TextMarkup] = []
        self.url: List[TextUrlMarkup] = []
        self.formatted_url: List[TextMarkup] = []
        self.command: List[TextMarkup] = []


class FormattingSettings:
    __slots__ = (
        'message',
        'text_markups'
    )

    def __init__(self, message: str, text_markups: Optional[TextMarkups] = None):
        self.message: str = message
        self.text_markups: TextMarkups = TextMarkups() if text_markups is None else text_markups

    def __str__(self):
        return f"message: {self.message} text_markups: {self.text_markups}"


class BBCodeFormatter:
    BOLD_GROUP_NAME = 'bold'
    ITALIC_GROUP_NAME = 'italic'
    UNDERLINE_GROUP_NAME = 'underline'
    STRIKE_GROUP_NAME = 'strike'
    MONOSPACE_GROUP_NAME = 'monospace'
    SHORT_URL_GROUP_NAME = 'short_url'
    URL_GROUP_NAME = 'url',
    FORMATTED_URL_GROUP_NAME = 'formatted_url',

    def __init__(self):
        self.__pattern_by_group_name: Dict[str, str] = {
            BBCodeFormatter.BOLD_GROUP_NAME: r'\[b\](.*?)\[/b\]',
            BBCodeFormatter.ITALIC_GROUP_NAME: r'|\[i\](.*?)\[/i\]',
            BBCodeFormatter.UNDERLINE_GROUP_NAME: r'|\[u\](.*?)\[/u\]',
            BBCodeFormatter.STRIKE_GROUP_NAME: r'|\[s\](.*?)\[/s\]',
            BBCodeFormatter.MONOSPACE_GROUP_NAME: r'|\[code\](.*?)\[/code\]',
            BBCodeFormatter.SHORT_URL_GROUP_NAME: r'|\[url\](.*?)\[/url\]',
            BBCodeFormatter.URL_GROUP_NAME: r'|\[url=(.*?)\](.*?)\[/url\]'
        }

        self.__pattern = re.compile(''.join(self.__pattern_by_group_name.values()), re.IGNORECASE)

        self.__excluded = re.compile(r'\[i\]|\[/i\]'
                                     r'|\[b\]|\[/b\]'
                                     r'|\[s\]|\[/s\]'
                                     r'|\[u\]|\[/u\]'
                                     r'|\[code\]|\[/code\]'
                                     r'|\[url\]|\[/url\]'
                                     r'|\[url=(.*?)\]', re.IGNORECASE)

    def extract(self, message_text: str) -> Optional[TextMarkups]:
        if message_text is None:
            return None
        skip, text_markup_dict = self.__extract(message_text)
        text_markups = TextMarkups()
        text_markups.bold = text_markup_dict.get(BBCodeFormatter.BOLD_GROUP_NAME, [])
        text_markups.italic = text_markup_dict.get(BBCodeFormatter.ITALIC_GROUP_NAME, [])
        text_markups.underline = text_markup_dict.get(BBCodeFormatter.UNDERLINE_GROUP_NAME, [])
        text_markups.strike = text_markup_dict.get(BBCodeFormatter.STRIKE_GROUP_NAME, [])
        text_markups.monospace = text_markup_dict.get(BBCodeFormatter.MONOSPACE_GROUP_NAME, [])
        text_markups.url = (text_markup_dict.get(BBCodeFormatter.URL_GROUP_NAME, [])
                            + text_markup_dict.get(BBCodeFormatter.SHORT_URL_GROUP_NAME, []))
        text_markups.formatted_url = text_markup_dict.get(BBCodeFormatter.FORMATTED_URL_GROUP_NAME, [])

        return text_markups

    def __extract(self,
                  message_text: str,
                  skipped_chars: Optional[int] = 0,
                  start_index: Optional[int] = 0) -> [int, Dict[str, List[TextMarkup]]]:

        text_markup_dict: Dict[str, List[TextMarkup]] = {}
        for match in re.finditer(self.__pattern, message_text):
            for index, group_name in enumerate(self.__pattern_by_group_name.keys()):
                group_match, url = self.__get_group_match_and_url(index, group_name, match)
                if group_match is not None:
                    word = re.sub(self.__excluded, '', group_match)
                    start = EmojiTextUtils.start(message_text, match.start(0)) + start_index - skipped_chars
                    skipped_chars += EmojiTextUtils.length(match.group(0)) - EmojiTextUtils.length(group_match)

                    inner_text_markup_dict = None
                    if EmojiTextUtils.length(word) != EmojiTextUtils.length(group_match):
                        inner_skip, inner_text_markup_dict = self.__extract(group_match, 0, start)
                        for key, values in inner_text_markup_dict.items():
                            text_markup_dict[key] = text_markup_dict.get(key, []) + values
                        skipped_chars += inner_skip

                    if BBCodeFormatter.__is_url(group_name) and inner_text_markup_dict is not None:
                        group_name = BBCodeFormatter.FORMATTED_URL_GROUP_NAME

                    text_markup = self.__create_text_markup(word, start, url)
                    text_markup_dict[group_name] = text_markup_dict.get(group_name, []) + [text_markup]

        return skipped_chars, text_markup_dict

    @staticmethod
    def __create_text_markup(word, start, url: str = None):
        if url is not None:
            return TextUrlMarkup(start, EmojiTextUtils.length(word), url)
        else:
            return TextMarkup(start, EmojiTextUtils.length(word))

    @staticmethod
    def __is_url(group_name: str) -> [str, str]:
        return group_name == BBCodeFormatter.URL_GROUP_NAME or group_name == BBCodeFormatter.SHORT_URL_GROUP_NAME

    @staticmethod
    def __get_group_match_and_url(index, group_name, match) -> [str, str]:
        url = None
        if group_name == BBCodeFormatter.URL_GROUP_NAME:
            group_match = match.group(index + 2)
            url = match.group(index + 1)
        elif group_name == BBCodeFormatter.SHORT_URL_GROUP_NAME:
            group_match = url = match.group(index + 1)
        else:
            group_match = match.group(index + 1)
        return group_match, url

    def format_text(self, message_text: str) -> FormattingSettings:
        if message_text is None:
            return FormattingSettings('', None)
        text_markups = self.extract(message_text)
        message_text = re.sub(self.__excluded, '', message_text)
        return FormattingSettings(message_text, text_markups)


class TextFormatter:
    command_pattern = re.compile(r'(?:^|\s)(/\w+)', re.IGNORECASE)

    __slots__ = ('bbcode_formatter',)

    def __init__(self, bbcode_formatter: BBCodeFormatter = BBCodeFormatter()):
        self.bbcode_formatter = bbcode_formatter

    def format_text(self, message_text: str) -> FormattingSettings:
        formatting_settings: FormattingSettings = self.bbcode_formatter.format_text(message_text)
        formatting_settings.text_markups.command = self.extract_message_command(formatting_settings.message)
        return formatting_settings

    @staticmethod
    def __extract(pattern, message_text: str) -> List[TextMarkup]:
        commands = []
        for match in re.finditer(pattern, message_text):
            commands.append(
                TextMarkup(EmojiTextUtils.start(message_text, match.start(1)), EmojiTextUtils.length(match.group(1))))
        return commands

    @staticmethod
    def extract_message_command(message_text: str) -> List[TextMarkup]:
        return TextFormatter.__extract(TextFormatter.command_pattern, message_text)


class EmojiTextUtils:
    @staticmethod
    def length(text: str) -> int:
        count = 0
        for char in text:
            count += 2 if ord(char) >= 0x10000 else 1  # Symbols with codes from 0x10000
                                                       # and higher require use of two 16-bit codes ("surrogate pairs")
        return count

    @staticmethod
    def start(message_text: str, start: int) -> int:
        sub_str = message_text[:start]
        length = EmojiTextUtils.length(sub_str)
        return length if length != len(sub_str) else start
