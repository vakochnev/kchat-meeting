import jmespath
import json
import logging
import sseclient
from abc import ABC
from typing import Any, Dict, List, Optional

from .data_classes import *
from .util import Request, MessageRequest, File, Image, Video


class BotEvent(ABC):
    """The container object for incoming events to a bot"""

    MESSAGE = 'message'
    MESSAGE_DELETE = 'message_delete'
    MESSAGES_DELETED = 'messages_deleted'
    MESSAGES_DELETED_COMPLETELY = 'messages_deleted_completely'
    MESSAGE_UPDATE = 'message_update'

    GROUP_USER_JOIN = 'group_user_join'
    GROUP_USERS_ADD = 'group_users_add'
    GROUP_USER_LEAVE = 'group_user_leave'
    GROUP_USER_REMOVE = 'group_user_remove'
    GROUP_ME_ADD = 'group_me_add'
    GROUP_ME_REMOVE = 'group_me_remove'
    GROUP_HISTORY_CLEAR = 'group_history_clear'
    GROUP_DELETE = 'group_delete'

    USER_UPDATE = 'user_update'
    USER_SIGNED_UP_TO_WORKSPACE = 'user_signed_up_to_workspace'

    PING = 'ping'

    __slots__ = ('_logger', '_request', '_type', '_payload', '_workspace_id', '_group_id', '_event_id', '_sender_id')

    def __init__(self, req: Request, sse: sseclient.Event):
        """Constructs :class:`BotEvent`.
         :param req: request :class:`Request` object.
         :param sse: sse event :class:`sseclient.Event` object."""
        self._logger = logging.getLogger('BotEvent')
        self._request = req
        self._type: str = sse.event
        self._event_id: int = sse.id
        self._sender_id = None
        if not self.is_ping:
            self._logger.debug('parsing sse %s', str(sse))
            json_data = self._loads(sse.data)
            self._logger.debug(f'event data {json_data}')
            self._workspace_id = json_data.get('workspaceId')
            self._group_id = json_data.get('groupId')
            p = json_data.get('payload', {})
            if not isinstance(p, dict):
                try:
                    p = json.loads(str(p))
                except Exception as e:
                    self._logger.exception('Error while parsing json', exc_info=e)
                    p = {}
            self._payload: Dict[str, Any] = p

    def _loads(self, data: str) -> Dict[str, Any]:
        res: Dict[str, Any]
        try:
            res = json.loads(json.loads(data).get('content'))
        except Exception as e:
            self._logger.exception('Error while parsing json', exc_info=e)
            res = {}
        return res

    def send_text_message(self, workspace_id: int, group_id: int, message: MessageRequest) -> Dict[str, Any]:
        return self._request.send_text(workspace_id, group_id, message)

    def send_text(self, workspace_id: int, group_id: int, text: str) -> Dict[str, Any]:
        return self._request.send_text(workspace_id, group_id, MessageRequest(text))

    def send_file(self, workspace_id: int, group_id: int, file_path: str, text: str = '') -> Dict[str, Any]:
        return self._request.send_file(workspace_id, group_id, file_path, text)

    def send_file_message(self, workspace_id: int, group_id: int, file: File,
                          message: MessageRequest = MessageRequest('')) -> Dict[str, Any]:
        return self._request.send_file_message(workspace_id, group_id, file, message)

    def update_file(self, workspace_id: int, group_id: int, message_id: int, file_path: str, text: str = '') -> Dict[
        str, Any]:
        return self._request.update_file(workspace_id, group_id, message_id, file_path, text)

    def update_file_message(self, workspace_id: int, group_id: int, message_id: int, file: File,
                            message: MessageRequest = MessageRequest('')) -> Dict[str, Any]:
        return self._request.update_file_message(workspace_id, group_id, message_id, file, message)

    def send_image(self, workspace_id: int, group_id: int, image_path: str, text: str = '') -> Dict[str, Any]:
        return self._request.send_image(workspace_id, group_id, image_path, text)

    def send_image_message(self, workspace_id: int, group_id: int, image: Image,
                           message: MessageRequest = MessageRequest('')) -> Dict[str, Any]:
        return self._request.send_image_message(workspace_id, group_id, image, message)

    def update_image(self, workspace_id: int, group_id: int, message_id: int, image_path: str, text: str = '') -> Dict[
        str, Any]:
        return self._request.update_image(workspace_id, group_id, message_id, image_path, text)

    def update_image_message(self, workspace_id: int, group_id: int, message_id: int, image: Image,
                             message: MessageRequest = MessageRequest('')) -> Dict[str, Any]:
        return self._request.update_image_message(workspace_id, group_id, message_id, image, message)

    def send_video(self, workspace_id: int, group_id: int, video_path: str, text: str = '') -> Dict[str, Any]:
        return self._request.send_video(workspace_id, group_id, video_path, text)

    def send_video_message(self, workspace_id: int, group_id: int, video: Video,
                           message: MessageRequest = MessageRequest('')) -> Dict[str, Any]:
        return self._request.send_video_message(workspace_id, group_id, video, message)

    def update_video(self, workspace_id: int, group_id: int, message_id: int, video_path: str, text: str = '') -> Dict[
        str, Any]:
        return self._request.update_video(workspace_id, group_id, message_id, video_path, text)

    def update_video_message(self, workspace_id: int, group_id: int, message_id: int, video: Video,
                             message: MessageRequest = MessageRequest('')) -> Dict[str, Any]:
        return self._request.update_video_message(workspace_id, group_id, message_id, video, message)

    def send_multimedia(self, workspace_id: int,
                        group_id: int,
                        images: Optional[List[Image]] = None,
                        videos: Optional[List[Video]] = None,
                        text: str = '') -> Dict[str, Any]:
        return self.send_multimedia_message(workspace_id, group_id, images, videos, MessageRequest(text))

    def send_multimedia_message(self, workspace_id: int,
                                group_id: int,
                                images: Optional[List[Image]] = None,
                                videos: Optional[List[Video]] = None,
                                message: MessageRequest = MessageRequest('')) -> Dict[str, Any]:
        return self._request.send_multimedia_message(workspace_id, group_id, images, videos, message)

    def delete_messages(self, workspace_id: int, group_id: int, message_ids: List[int]) -> None:
        self._request.delete_messages(workspace_id, group_id, message_ids)

    def join_user_by_invite_link(self, link: str) -> None:
        self._request.join_user_by_invite_link(link)

    def confirm_event(self, workspace_id: int, group_id: int, last_event_id: int) -> None:
        self._request.confirm_events(workspace_id, {group_id: last_event_id})

    @property
    def event_id(self) -> int:
        return self._event_id

    @property
    def event_type(self) -> str:
        return self._type.lower()

    @property
    def workspace_id(self) -> int:
        return self._workspace_id

    @property
    def group_id(self) -> int:
        return self._group_id

    @property
    def sender_id(self) -> int:
        return self._sender_id

    @property
    def is_ping(self) -> bool:
        return self.event_type == BotEvent.PING

    @property
    def is_message(self) -> bool:
        return self.event_type == BotEvent.MESSAGE

    def get_payload_data(self, path: Optional[str] = None) -> Any:
        """
        Returns the value at the given path, if there is no path returns the entire event payload.
        For example:
                payload = {
                     'user': {
                         'id': 1
                     }
                 }
                 user_id = event.get_payload_data('user.id')
        :param path: Path to a field in a nested structure.
        :return: object.
        """
        if path is None:
            return self._payload

        return jmespath.search(path, self._payload)


class GroupUserRemoveBotEvent(BotEvent):
    @property
    def group(self) -> Optional[Dict]:
        return self.get_payload_data('group')

    @property
    def user(self) -> Optional[Dict]:
        return self.get_payload_data('user')

    @property
    def requester(self) -> Optional[Dict]:
        return self.get_payload_data('requester')


class GroupMeRemoveBotEvent(BotEvent):
    @property
    def group_id(self) -> Optional[int]:
        return self.get_payload_data('groupId')

    @property
    def user(self) -> Optional[Dict]:
        return self.get_payload_data('user')

    @property
    def requester(self) -> Optional[Dict]:
        return self.get_payload_data('requester')


class GroupUserLeaveBotEvent(BotEvent):
    @property
    def group(self) -> Optional[Dict]:
        return self.get_payload_data('group')

    @property
    def user(self) -> Optional[Dict]:
        return self.get_payload_data('user')


class GroupUsersAddBotEvent(BotEvent):
    @property
    def group(self) -> Optional[Dict]:
        return self.get_payload_data('group')

    @property
    def users(self) -> Optional[List[Dict]]:
        return self.get_payload_data('users')

    @property
    def requester(self) -> Optional[Dict]:
        return self.get_payload_data('requester')


class GroupMeAddBotEvent(BotEvent):
    @property
    def group_state(self) -> Optional[Dict]:
        return self.get_payload_data('groupState')

    @property
    def user(self) -> Optional[Dict]:
        return self.get_payload_data('user')

    @property
    def requester(self) -> Optional[Dict]:
        return self.get_payload_data('requester')


class GroupUserJoinBotEvent(BotEvent):
    @property
    def group(self) -> Optional[Dict]:
        return self.get_payload_data('group')

    @property
    def user(self) -> Optional[Dict]:
        return self.get_payload_data('user')


class DeleteGroupBotEvent(BotEvent):
    @property
    def group(self) -> Optional[Dict]:
        return self.get_payload_data('group')

    @property
    def deleted_by(self) -> Optional[int]:
        return self.get_payload_data('deletedBy')


class HistoryClearGroupBotEvent(BotEvent):

    @property
    def group_id(self) -> Optional[int]:
        return self.get_payload_data('groupId')

    @property
    def initial_message_id(self) -> Optional[int]:
        return self.get_payload_data('initialMessageId')

    @property
    def initial_message_position(self) -> Optional[int]:
        return self.get_payload_data('initialMessagePosition')


class BaseMessageBotEvent(BotEvent):

    def reply_text_message(self, message: MessageRequest) -> Dict[str, Any]:
        return self._request.send_text(self._workspace_id, self._group_id, message)

    def reply_text(self, text: str) -> Dict[str, Any]:
        return self._request.send_text(self._workspace_id, self._group_id, MessageRequest(text))

    def reply_file(self, file_path: str, message: str = '') -> Dict[str, Any]:
        return self._request.send_file(self._workspace_id, self._group_id, file_path, message)

    def reply_file_message(self, file: File, message: MessageRequest = MessageRequest('')) -> Dict[str, Any]:
        return self._request.send_file_message(self._workspace_id, self._group_id, file, message)

    def reply_multimedia(self, images: Optional[List[Image]] = None,
                         videos: Optional[List[Video]] = None,
                         message: str = '') -> Dict[str, Any]:
        return self.reply_multimedia_message(images, videos, MessageRequest(message))

    def reply_multimedia_message(self,
                                 images: Optional[List[Image]] = None,
                                 videos: Optional[List[Video]] = None,
                                 message: MessageRequest = MessageRequest('')) -> Dict[str, Any]:
        return self._request.send_multimedia_message(self._workspace_id, self._group_id, images, videos, message)

    def confirm_read(self, last_msg_id: int) -> None:
        self._request.confirm(self._workspace_id, self._group_id, last_msg_id)

    def delete_messages_from_current_group(self, message_ids: List[int]) -> None:
        self._request.delete_messages(self._workspace_id, self._group_id, message_ids)

    def confirm_event_from_current_group(self, last_event_id: int) -> None:
        self._request.confirm_events(self._workspace_id, {self._group_id: last_event_id})


class MessageBotEvent(BaseMessageBotEvent):

    def __init__(self, req: Request, sse: sseclient.Event):
        super().__init__(req, sse)
        self._set_messages()

    def _set_messages(self):
        data: List[Dict] = self.get_payload_data("messages")
        self._messages: List[MessageBase] = [MessageBase.from_dict(item) for item in data]

    @property
    def message_text(self) -> Optional[str]:
        first_msg = self._get_first_msg()
        return first_msg.message if first_msg is not None else None

    @property
    def comment(self) -> Optional[Comments]:
        first_msg = self._get_first_msg()
        return first_msg.comments if first_msg is not None else None

    @property
    def reply_message_id(self) -> Optional[int]:
        first_msg = self._get_first_msg()
        return first_msg.reply_msg_id if first_msg is not None else None

    @property
    def has_selected_button(self) -> bool:
        return self.selected_button is not None

    @property
    def selected_button(self) -> Optional[SelectedButton]:
        first_msg = self._get_first_msg()
        if first_msg is None:
            return None
        metadata = first_msg.metadata
        if metadata is not None and metadata.type == 'SELECTED_BUTTON':
            return SelectedButton.from_dict(metadata.selected_button)

    @property
    def sender_id(self) -> Optional[int]:
        return self._get_first_msg().sender_id if self._has_message() else None

    @property
    def message_id(self) -> int:
        return self._get_first_msg().id if self._has_message() else None

    def _get_first_msg(self) -> Optional[MessageBase]:
        return self._messages[0] if self._has_message() else None

    def _has_message(self) -> bool:
        return len(self._messages) > 0


class MessageUpdateBotEvent(MessageBotEvent):

    def _set_messages(self):
        data: List[Dict] = self.get_payload_data("message")
        self._messages: List[MessageBase] = [MessageBase.from_dict(data)] if data is not None else []


class MessageDeleteBotEvent(MessageBotEvent):

    def _set_messages(self):
        data: Optional[Dict] = self._payload.get("message", None)
        self._messages: List[MessageBase] = [MessageBase.from_dict(data)] if data is not None else []


class MessagesDeleteBotEvent(BaseMessageBotEvent):
    def __init__(self, req: Request, sse: sseclient.Event):
        super().__init__(req, sse)
        data: List[Dict] = self.get_payload_data("messages")
        self._messages: List[MessageBase] = [MessageBase.from_dict(item) for item in data]

    @property
    def sender_id(self) -> Optional[int]:
        return self._messages[0].sender_id if len(self._messages) > 0 else None


class MessagesDeletedCompletelyBotEvent(BaseMessageBotEvent):
    def __init__(self, req: Request, sse: sseclient.Event):
        super().__init__(req, sse)
        data: List[Dict] = self.get_payload_data("messages")
        self._messages: List[MessageBase] = [MessageBase.from_dict(item) for item in data]

    @property
    def sender_id(self) -> Optional[int]:
        return self._messages[0].sender_id if len(self._messages) > 0 else None


class UserSignedUpToWorkspaceBotEvent(BotEvent):
    @property
    def user(self) -> Optional[Dict]:
        return self.get_payload_data('user')


class UserUpdateBotEvent(BotEvent):
    @property
    def user(self) -> Optional[Dict]:
        return self.get_payload_data('user')
