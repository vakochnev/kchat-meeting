from dataclasses import dataclass, field
from typing import List, Dict, Optional


@dataclass
class InlineMessageButton:
    id: int = field(default=None)
    label: str = field(default=None)
    callback_message: str = field(default=None)
    callback_data: str = field(default=None)

    @staticmethod
    def from_dict(inline_message_button_dict: Optional[Dict] = None) -> Optional['InlineMessageButton']:
        if inline_message_button_dict is None:
            return None
        inline_message_button = InlineMessageButton()
        inline_message_button.id = inline_message_button_dict.get('id', None)
        inline_message_button.label = inline_message_button_dict.get('label', None)
        inline_message_button.callback_message = inline_message_button_dict.get('callbackMessage', None)
        inline_message_button.callback_data = inline_message_button_dict.get('callbackData', None)
        return inline_message_button


@dataclass
class ButtonsMarkup:
    inline_message_buttons: List[InlineMessageButton] = field(default=None)

    @staticmethod
    def from_dict(buttons_markup_dict: Optional[Dict] = None) -> Optional['ButtonsMarkup']:
        if buttons_markup_dict is None:
            return None
        buttons_markup = ButtonsMarkup()
        buttons_markup.inline_message_buttons = [InlineMessageButton.from_dict(button) for button in
                                                 buttons_markup_dict.get('inline_message_buttons', [])]
        return buttons_markup


@dataclass
class Comments:
    amount: int = field(default=None)
    virtual_group_id: int = field(default=None)

    @staticmethod
    def from_dict(comments_dict: Optional[Dict] = None) -> Optional['Comments']:
        if comments_dict is None:
            return None
        comments = Comments()
        comments.amount = comments_dict.get('amount', None)
        comments.virtual_group_id = comments_dict.get('virtualGroupId', None)
        return comments


@dataclass
class SelectedButton:
    id: int = field(default=None)
    callback_data: str = field(default=None)

    @staticmethod
    def from_dict(selected_button_dict: Optional[Dict] = None) -> Optional['SelectedButton']:
        if selected_button_dict is None:
            return None
        selected_button = SelectedButton()
        selected_button.id = selected_button_dict.get('id', None)
        selected_button.callback_data = selected_button_dict.get('callbackData', None)
        return selected_button


@dataclass
class Metadata:
    type: str = field(default=None)
    selected_button: SelectedButton = field(default=None)
    version: int = field(default=None)

    @staticmethod
    def from_dict(metadata_dict: Optional[Dict] = None) -> Optional['Metadata']:
        if metadata_dict is None:
            return None
        metadata = Metadata()
        metadata.type = metadata_dict.get('type', None)
        metadata.selected_button = metadata_dict.get('selectedButton', None)
        metadata.version = metadata_dict.get('version', None)
        return metadata


@dataclass
class MessageBase:
    id: int = field(default=None)
    group_id: int = field(default=None)
    sender_id: int = field(default=None)
    reply_msg_id: int = field(default=None)
    message: str = field(default=None)
    metadata: Metadata = field(default=None)
    comments: Comments = field(default=None)
    buttons_markup: ButtonsMarkup = field(default=None)

    @staticmethod
    def from_dict(message_dict: Optional[Dict] = None) -> Optional['MessageBase']:
        if message_dict is None:
            return None
        message_base = MessageBase()
        message_base.id = message_dict.get('id', None)
        message_base.group_id = message_dict.get('groupId', None)
        message_base.sender_id = message_dict.get('senderId', None)
        message_base.message = message_dict.get('message', None)
        message_base.reply_msg_id = message_dict.get('replyMsgId', None)
        message_base.metadata = Metadata.from_dict(message_dict.get('metadata', None))
        message_base.comments = Comments.from_dict(message_dict.get('comments', None))
        message_base.buttons_markup = ButtonsMarkup.from_dict(message_dict.get('buttonsMarkup', None))
        return message_base
